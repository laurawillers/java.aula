package dao;

import java.util.List;
import java.util.Optional;

public interface GenericDAO<T, ID> {
    public void inserir(T entidade);
    public List<T> listar();
    public Optional<T> buscaPorId(ID id);
    public void atualizar(T entidade);
    public void excluir(ID id);
}
